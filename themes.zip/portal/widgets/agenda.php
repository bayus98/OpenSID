<?php  if(!defined('BASEPATH')) exit('No direct script access allowed'); ?>

<!-- Widget Agenda -->
<?php if ($agenda): ?>
	<div class="widget-agenda">
		<ul id="ul-menu" class="sidebar-latest">
			<?php foreach ($agenda as $data): ?>
				<li>
					<a
					href="<?php echo site_url( 'berita/agenda/'.$data['slug'] ); ?>"><?php echo $data['judul']; ?></a>
					<small class="text-muted">( <?php echo tgl_indo($data['tgl_upload']); ?> )</small>
				</li>
			<?php endforeach; ?>
		</ul>
	</div>
	<?php endif; ?>