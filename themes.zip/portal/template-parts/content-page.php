<?php  if(!defined('BASEPATH')) exit('No direct script access allowed'); ?>

<?php if(is_file(LOKASI_FOTO_ARTIKEL.'sedang_'.$content['gambar'])) { ?>
	<img width="100%" class="img-responsive" src="<?php echo base_url().LOKASI_FOTO_ARTIKEL.'sedang_'.$content['gambar']; ?>" alt="<?php echo $content['judul']; ?>">
<?php } ?>

<div class="box">
	<div class="box-header">
		<div class="meta-content">
			<small>Diterbitkan oleh <?php echo $content['owner']; ?>, <?php echo tgl_indo2( $content['tgl_upload'] ); ?></small>
		</div>
	</div>

	<div class="box-body">
		<h1 class="title"><?php echo $page_header; ?></h1>
		<?php echo $content['isi']; ?>
	</div>
</div>

<?php //$this->load->view($folder_themes.'/comments');?>