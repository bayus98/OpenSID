<?php  if(!defined('BASEPATH')) exit('No direct script access allowed'); ?>


<!-- Navigation -->
<nav class="navbar navbar-default hidden-lg hidden-md" role="navigation">
	
    <!-- Brand and toggle get grouped for better mobile display -->
    <div class="navbar-header">
		<div class="logo-menu hidden-lg hidden-md"><a href="<?php echo site_url(); ?>"><img src="<?php echo base_url().'desa/logo/'.$desa['logo']; ?>" alt="Logo Desa" width="30">
			<span class="logo-title">
				<?php echo ucwords($this->setting->sebutan_desa)." "?><?php echo ucwords($desa['nama_desa'])?>
			</span>
			</a>
		</div>
    </div>
</nav>
