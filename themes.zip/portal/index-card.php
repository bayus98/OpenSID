<?php  if(!defined('BASEPATH')) exit('No direct script access allowed'); ?>
<div class="container">
	<div class="index-menu">
		<div class="row">
			<div class="col-md-2 col-xs-4 text-center badget">
                <a class="text-primary" href="<?php echo site_url('berita'); ?>">
                <div class="card-bg bg-biru">
                    <div class="card-body bg-light">
                        <img class="text-center" src="<?= base_url()?>/themes/portal/assets/images/badget/berita.png" alt="Berita Desa">
                        <div class="index-card-title">Berita</div>
                    </div>
                </div>
                </a>
            </div>

            <div class="col-md-2 col-xs-4 text-center badget">
                <a class="text-primary" href="<?php echo site_url('page'); ?>">
                <div class="card-bg bg-hijau">
                    <div class="card-body bg-light">
                        <img class="text-center" src="<?= base_url()?>/themes/portal/assets/images/badget/profil_desa.png" alt="Profil Desa">
                         <div class="index-card-title">Profil <?php echo ucwords($this->setting->sebutan_desa); ?></div>
                    </div>
                </div>
                </a>
            </div>
			
			<div class="col-md-2 col-xs-4 text-center badget">
                <a class="text-primary" href="<?php echo site_url('pemerintah'); ?>">
                <div class="card-bg bg-ungu">
                    <div class="card-body bg-light">
                        <img class="text-center" src="<?= base_url()?>/themes/portal/assets/images/badget/pemerintah.png" alt="Pemerintah Desa">
                         <div class="index-card-title">Pemerintah</div>
                    </div>
                </div>
                </a>
            </div>
			
			<div class="col-md-2 col-xs-4 text-center badget">
                <a class="text-primary" href="<?php echo site_url('inventaris'); ?>">
                <div class="card-bg bg-yellow">
                    <div class="card-body bg-light">
                        <img class="text-center" src="<?= base_url()?>/themes/portal/assets/images/badget/aset.png" alt="Aset Desa">
                         <div class="index-card-title">Aset <?php echo ucwords($this->setting->sebutan_desa); ?></div>
                    </div>
                </div>
                </a>
            </div>
			
			<div class="col-md-2 col-xs-4 text-center badget">
                <a class="text-primary" href="<?php echo site_url('downloads'); ?>">
                <div class="card-bg bg-success">
                    <div class="card-body bg-light">
                        <img class="text-center" src="<?= base_url()?>/themes/portal/assets/images/badget/perdes.png" alt="Peraturan Desa">
                         <div class="index-card-title">Regulasi</div>
                    </div>
                </div>
                </a>
            </div>

            <div class="col-md-2 col-xs-4 text-center badget">
                <a class="text-primary" href="<?php echo site_url('data-apbdes'); ?>">
                <div class="card-bg bg-cyan">
                    <div class="card-body bg-light">
                        <img class="text-center" src="<?= base_url()?>/themes/portal/assets/images/badget/apbdes.png" alt="Dana Desa">
                        <div class="index-card-title">Anggaran</div>
                    </div>
                </div>
                </a>
            </div>

            <div class="col-md-2 col-xs-4 text-center badget">
                <a class="text-primary" href="<?php echo site_url('statistik/list'); ?>">
                <div class="card-bg bg-orange">
                    <div class="card-body bg-light">
                        <img class="text-center" src="<?= base_url()?>/themes/portal/assets/images/badget/statistik.png" alt="Statistik Desa">
                        <div class="index-card-title">Statistik</div>
                    </div>
                </div>
                </a>
            </div>
			
			<div class="col-md-2 col-xs-4 text-center badget">
                <a class="text-primary" href="<?php echo site_url('agenda'); ?>">
                <div class="card-bg bg-success">
                    <div class="card-body bg-light">
                        <img class="text-center" src="<?= base_url()?>/themes/portal/assets/images/badget/calendar.png" alt="Agenda Desa">
                        <div class="index-card-title">Agenda</div>
                    </div>
                </div>
                </a>
            </div>
			
			<div class="col-md-2 col-xs-4 text-center badget">
                <a class="text-primary" href="<?php echo site_url('maps'); ?>">
                <div class="card-bg bg-cyan">
                    <div class="card-body bg-light">
                        <img class="text-center" src="<?= base_url()?>/themes/portal/assets/images/badget/peta.png" alt="Peta Desa">
                        <div class="index-card-title">Peta <?php echo ucwords($this->setting->sebutan_desa); ?></div>
                    </div>
                </div>
                </a>
            </div>
				
			<div class="col-md-2 col-xs-4 text-center badget">
                <a class="text-primary" href="<?php echo site_url('albums'); ?>">
                <div class="card-bg bg-magenta">
                    <div class="card-body bg-light">
                        <img class="text-center" src="<?= base_url()?>/themes/portal/assets/images/badget/galeri.png" alt="Album Foto">
                        <div class="index-card-title">Galeri Foto</div>
                    </div>
                </div>
                </a>
            </div>

            <div class="col-md-2 col-xs-4 text-center badget">
                <a class="text-primary" href="<?php echo site_url('layanan_mandiri'); ?>">
                <div class="card-bg bg-merah">
                    <div class="card-body bg-light">
                        <img class="text-center" src="<?= base_url()?>/themes/portal/assets/images/badget/mandiri.png" alt="Layanan Mandiri">
                        <div class="index-card-title">Layanan</div>
                    </div>
                </div>
                </a>
            </div>
		</div>	
	</div>
</div>