<?php  if(!defined('BASEPATH')) exit('No direct script access allowed'); ?>

<div class="box">
	<div class="box-header">
		<h3><?php echo $page_header ?></h3>
	</div>
	<div class="box-body">
		<?php if(count($main) > 0) { ?>
			<table class="table table-sm table-bordered table-striped">
				<thead>
					<tr>
						<th class="text-center" width="2">No</th>
						<th class="text-center">Nama <?php echo ucwords($this->setting->sebutan_dusun)?></th>
						<th class="text-center">Nama <?php echo ucwords($this->setting->sebutan_singkatan_kadus)?></th>
						<th class="text-center" width="80">Jumlah RT</th>
						<th class="text-center" width="80">Jumlah KK</th>
						<th class="text-center" width="80">Jiwa</th>
						<th class="text-center" width="80">Laki-laki</th>
						<th class="text-center" width="80">Perempuan</th>
					</tr>
				</thead>

				<tbody>
					<?php foreach($main as $data){ ?>
						<tr>
							<td class="text-center"><?php echo $data['no']; ?></td>
							<td><?php echo strtoupper(unpenetration(ununderscore($data['dusun']))); ?></td>
							<td><?php echo strtoupper(unpenetration($data['nama_kadus'])); ?></td>
							<td class="text-center"><?php echo $data['jumlah_rt']; ?></td>
							<td class="text-center"><?php echo $data['jumlah_kk']; ?></td>
							<td class="text-center"><?php echo $data['jumlah_warga']; ?></td>
							<td class="text-center"><?php echo $data['jumlah_warga_l']; ?></td>
							<td class="text-center"><?php echo $data['jumlah_warga_p']; ?></td>
						</tr>
					<?php } ?>
				</tbody>
					<tr>
						<th colspan=3 class="text-center">TOTAL</th>
						<th class="text-center"><?php echo $total['total_rt']; ?></th>
						<th class="text-center"><?php echo $total['total_kk']; ?></th>
						<th class="text-center"><?php echo $total['total_warga']; ?></th>
						<th class="text-center"><?php echo $total['total_warga_l']; ?></th>
						<th class="text-center"><?php echo $total['total_warga_p']; ?></th>
					</tr>
			</table>
		<?php } else { ?>
			<div class="alert alert-danger">Belum ada data</div>
		<?php } ?>
	</div>
</div>

