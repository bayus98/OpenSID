<?php  if(!defined('BASEPATH')) exit('No direct script access allowed'); ?>

<div class="box no-padd">
	<div class="box-body">
		<?php if(count($main) > 0){ ?>
			<div class="table-responsive">
				<table class="table table-striped table-bordered table-sm text-center">
					<thead>
						<tr>
							<th width="50">No</th>
							<th class="text-left">Nama Dusun</th>
							<th>RW</th>
							<th>Jiwa</th>
							<th width="100">L</th>
							<th width="100">P</th>
						</tr>
					</thead>

					<tbody>
						<?php foreach($main as $data){ ?>
							<tr>
								<td><?php echo $data['no']; ?></td>
								<td class="text-left"><?php echo strtoupper($data['dusun']); ?></td>
								<td><?php echo strtoupper($data['rw']); ?></td>
								<td class="angka"><?php echo $data['jumlah_warga']; ?></td>
								<td class="angka"><?php echo $data['jumlah_warga_l']; ?></td>
								<td class="angka"><?php echo $data['jumlah_warga_p']; ?></td>
							</tr>
						<?php } ?>
					</tbody>

					<tfooter>
						<tr>
							<th colspan="3" class="angka">TOTAL</th>
							<th class="angka"><?php echo $total['total_warga']; ?></th>
							<th class="angka"><?php echo $total['total_warga_l']; ?></th>
							<th class="angka"><?php echo $total['total_warga_p']; ?></th>
						</tr>
					</tfooter>
				</table>
			</div>
		<?php } else { ?>
			<div class="alert alert-danger">Belum ada data</div>
		<?php } ?>
	</div>
</div>