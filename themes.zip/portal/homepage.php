<?php  if(!defined('BASEPATH')) exit('No direct script access allowed'); ?>

<?php $this->load->view($folder_themes.'/index-header');?>
<?php include('template-parts/menu/index-menu.php');?>
<?php $this->load->view($folder_themes.'/index-card');?>
<?php $this->load->view($folder_themes.'/index-footer');?>
