<?php if (!defined('BASEPATH')) exit('No direct script access allowed'); ?>

<div class="panel">
    <div class="dl-title"><?php echo $heading; ?></div>
    <div class="panel-body">
        <div class="col-md-2 col-xs-6 text-center badget">
            <a class="text-primary" href="<?php echo site_url('wilayah'); ?>">
                <div class="card-bg bg-success">
                    <div class="card-body">
                        <i class="fa fa-map fa-4x text-white"></i>
                        <div class="stat-card-title">Wilayah</div>
                    </div>
                </div>
            </a>
        </div>

        <div class="col-md-2 col-xs-6 text-center badget">
            <a class="text-primary" href="<?php echo site_url('statistik/13'); ?>">
                <div class="card-bg bg-success">
                    <div class="card-body">
                        <i class="fa fa-blind fa-4x text-white"></i>
                        <div class="stat-card-title">Usia</div>
                    </div>
                </div>
            </a>
        </div>
        <div class="col-md-2 col-xs-6 text-center badget">
            <a class="text-primary" href="<?php echo site_url('statistik/0'); ?>">
                <div class="card-bg bg-success">
                    <div class="card-body ">
                        <i class="fa fa-graduation-cap fa-4x text-white"></i>
                        <div class="stat-card-title">Pendidikan Dalam KK</div>
                    </div>
                </div>
            </a>
        </div>
        <div class="col-md-2 col-xs-6 text-center badget">
            <a class="text-primary" href="<?php echo site_url('statistik/14'); ?>">
                <div class="card-bg bg-success">
                    <div class="card-body">
                        <i class="fa fa-graduation-cap fa-4x text-white"></i>
                        <div class="stat-card-title">Pendidikan Ditempuh</div>
                    </div>
                </div>
            </a>
        </div>
        <div class="col-md-2 col-xs-6 text-center badget">
            <a class="text-primary" href="<?php echo site_url('statistik/1'); ?>">
                <div class="card-bg bg-success">
                    <div class="card-body">
                        <i class="fa fa-briefcase fa-4x text-white"></i>
                        <div class="stat-card-title">Pekerjaan</div>
                    </div>
                </div>
            </a>
        </div>
        <div class="col-md-2 col-xs-6 text-center badget">
            <a class="text-primary" href="<?php echo site_url('statistik/2'); ?>">
                <div class="card-bg bg-success">
                    <div class="card-body">
                        <i class="fa fa-bullhorn fa-4x text-white"></i>
                        <div class="stat-card-title">Perkawinan</div>
                    </div>
                </div>
            </a>
        </div>
        <div class="col-md-2 col-xs-6 text-center badget">
            <a class="text-primary" href="<?php echo site_url('statistik/3'); ?>">
                <div class="card-bg bg-success">
                    <div class="card-body">
                        <i class="fa fa-bullhorn fa-4x text-white"></i>
                        <div class="stat-card-title">Agama</div>
                    </div>
                </div>
            </a>
        </div>
        <div class="col-md-2 col-xs-6 text-center badget">
            <a class="text-primary" href="<?php echo site_url('statistik/4'); ?>">
                <div class="card-bg bg-success">
                    <div class="card-body">
                        <i class="fa fa-venus-mars fa-4x text-white"></i>
                        <div class="stat-card-title">Jenis Kelamin</div>
                    </div>
                </div>
            </a>
        </div>
        <div class="col-md-2 col-xs-6 text-center badget">
            <a class="text-primary" href="<?php echo site_url('statistik/6'); ?>">
                <div class="card-bg bg-success">
                    <div class="card-body">
                        <i class="fa fa-check-square-o fa-4x text-white"></i>
                        <div class="stat-card-title">Status</div>
                    </div>
                </div>
            </a>
        </div>
        <div class="col-md-2 col-xs-6 text-center badget">
            <a class="text-primary" href="<?php echo site_url('statistik/5'); ?>">
                <div class="card-bg bg-success">
                    <div class="card-body">
                        <i class="fa fa-flag fa-4x text-white"></i>
                        <div class="stat-card-title">Kewarganegaraan</div>
                    </div>
                </div>
            </a>
        </div>
        <div class="col-md-2 col-xs-6 text-center badget">
            <a class="text-primary" href="<?php echo site_url('statistik/18'); ?>">
                <div class="card-bg bg-success">
                    <div class="card-body">
                        <i class="fa fa-id-card-o fa-4x text-white"></i>
                        <div class="stat-card-title">KTP</div>
                    </div>
                </div>
            </a>
        </div>
        <div class="col-md-2 col-xs-6 text-center badget">
            <a class="text-primary" href="<?php echo site_url('statistik/18'); ?>">
                <div class="card-bg bg-success">
                    <div class="card-body">
                        <i class="fa fa-language fa-4x text-white"></i>
                        <div class="stat-card-title">Akta Kelahiran</div>
                    </div>
                </div>
            </a>
        </div>
        <div class="col-md-2 col-xs-6 text-center badget">
            <a class="text-primary" href="<?php echo site_url('statistik/9'); ?>">
                <div class="card-bg bg-success">
                    <div class="card-body">
                        <i class="fa fa-wheelchair fa-4x text-white"></i>
                        <div class="stat-card-title">Penyandang Cacat</div>
                    </div>
                </div>
            </a>
        </div>
        <div class="col-md-2 col-xs-6 text-center badget">
            <a class="text-primary" href="<?php echo site_url('statistik/10'); ?>">
                <div class="card-bg bg-success">
                    <div class="card-body">
                        <i class="fa fa-heartbeat fa-4x text-white"></i>
                        <div class="stat-card-title">Sakit Menahun</div>
                    </div>
                </div>
            </a>
        </div>
        <div class="col-md-2 col-xs-6 text-center badget">
            <a class="text-primary" href="<?php echo site_url('statistik/7'); ?>">
                <div class="card-bg bg-success">
                    <div class="card-body">
                        <i class="fa fa-medkit fa-4x text-white"></i>
                        <div class="stat-card-title">Golongan Darah</div>
                    </div>
                </div>
            </a>
        </div>
        <div class="col-md-2 col-xs-6 text-center badget">
            <a class="text-primary" href="<?php echo site_url('data-dpt'); ?>">
                <div class="card-bg bg-success">
                    <div class="card-body">
                        <i class="fa fa-check-circle-o fa-4x text-white"></i>
                        <div class="stat-card-title">Calon Pemilih</div>
                    </div>
                </div>
            </a>
        </div>
        <div class="col-md-2 col-xs-6 text-center badget">
            <a class="text-primary" href="<?php echo site_url('analisis'); ?>">
                <div class="card-bg bg-success">
                    <div class="card-body">
                        <i class="fa fa-search fa-4x text-white"></i>
                        <div class="stat-card-title">Analisis</div>
                    </div>
                </div>
            </a>
        </div>
        <div class="col-md-2 col-xs-6 text-center badget">
            <a class="text-primary" href="<?php echo site_url('statistik/kelas_sosial'); ?>">
                <div class="card-bg bg-success">
                    <div class="card-body">
                        <i class="fa fa-users fa-4x text-white"></i>
                        <div class="stat-card-title">Kelas Sosial</div>
                    </div>
                </div>
            </a>
        </div>
    </div>
</div>