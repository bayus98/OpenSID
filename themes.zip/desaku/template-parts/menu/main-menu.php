<?php if (!defined('BASEPATH')) exit('No direct script access allowed'); ?>


<!-- Navigation -->
<nav class="navbar navbar-expand-lg navbar-light bg-success" role="navigation">

    <!-- Brand and toggle get grouped for better mobile display -->
    <div class="navbar-header">
        <div class="logo-menu hidden-lg hidden-md"><a href="<?php echo site_url(); ?>"><img src="<?php echo base_url() . 'desa/logo/' . $desa['logo']; ?>" alt="Logo Desa" width="30">
                <span class="logo-title">
                    <?php echo ucwords($this->setting->sebutan_desa) . " " ?><?php echo ucwords($desa['nama_desa']) ?>
                </span>
            </a>
        </div>
        <button class="navbar-toggler" type="button" data-toggle="collapse" data-target="#navbarNavDropdown" aria-controls="navbarNavDropdown" aria-expanded="false" aria-label="Toggle navigation">
            <span class="navbar-toggler-icon"></span>
        </button>
    </div>

    <!-- Collect the nav links, forms, and other content for toggling -->
    <div class="collapse navbar-collapse" id="navbarNavDropdown" id="navbar">

        <ul class="navbar-nav">
            <li class="nav-item active">
                <a class="nav-link text-white" href="<?php echo site_url(); ?>">Beranda <span class="sr-only">(current)</span></a>
            </li>

            <?php foreach ($menu_atas as $data) { ?>

                <li class="<?php echo count($data['submenu']) > 0 ? 'dropdown' : '' ?>">
                    <a <?php echo count($data['submenu']) > 0 ? 'data-toggle="dropdown"' : ''; ?> class="nav-link text-white  <?php echo count($data['submenu']) > 0 ? 'dropdown-toggle' : ''; ?>" id="navbarDropdownMenuLink" role="button" data-toggle="dropdown" aria-haspopup="true" aria-expanded="false" href="<?php echo count($data['submenu']) > 0 ? '#' : $data['link']; ?>">
                        <?php echo $data['nama'] ?> <?php if (count($data['submenu']) > 0) { ?><?php } ?>
                    </a>
                    <?php if (count($data['submenu']) > 0) { ?>
                        <ul class="dropdown-menu">
                            <?php foreach ($data['submenu'] as $submenu) { ?>
                                <li><a href="<?php echo $submenu['link']; ?>"><?php echo $submenu['nama']; ?></a></li>
                            <?php } ?>
                        </ul>
                    <?php } ?>
                </li>

            <?php } ?>
        </ul>
    </div><!-- /.navbar-collapse -->
</nav>