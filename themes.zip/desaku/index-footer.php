<?php if (!defined('BASEPATH')) exit('No direct script access allowed'); ?>
<div class="container">
	<div class="index-footer">
		<div class="footer-bottom">
			<div class="social-footer">


			</div>
			<div class="web-copyright">
				<?php echo ucwords($this->setting->copyright_desa) . " " ?>. <?php echo AmbilVersi() ?>
			</div>
		</div>
	</div>
</div> <!-- /.wrapper -->

<!-- Untuk menampilkan modal -->
<div class="modal fade" id="modalBox" role="dialog" aria-labelledby="myModalLabel" aria-hidden="true">
	<div class='modal-dialog'>
		<div class='modal-content'>
			<div class='modal-header'>
				<button type='button' class='close' data-dismiss='modal' aria-hidden='true'>&times;</button>
				<h4 class='modal-title' id='myModalLabel'> Pengaturan Pengguna</h4>
			</div>

			<div class="fetched-data"></div>
		</div>
	</div>
</div>

<script src="<?php echo base_url(); ?>/assets/bootstrap/js/moment.min.js"></script>
<!-- Bootstrap 3.3.7 -->
<script src="<?php echo base_url(); ?>/assets/bootstrap/js/bootstrap.min.js"></script>
<!-- Select2 -->
<script src="<?php echo base_url(); ?>/assets/bootstrap/js/select2.full.min.js"></script>
<script src="<?php echo base_url(); ?>/assets/bootstrap/js/select2.full.min.js"></script>
<!-- DataTables -->
<script src="<?php echo base_url(); ?>/assets/bootstrap/js/jquery.dataTables.min.js"></script>
<script src="<?php echo base_url(); ?>/assets/bootstrap/js/dataTables.bootstrap.min.js"></script>
<!-- bootstrap Date time picker -->
<script src="<?php echo base_url(); ?>/assets/bootstrap/js/bootstrap-datetimepicker.min.js"></script>
<script src="<?php echo base_url(); ?>/assets/bootstrap/js/id.js"></script>
<!-- bootstrap Date picker -->
<script src="<?php echo base_url() ?>/assets/bootstrap/js/bootstrap-datepicker.min.js"></script>
<script src="<?php echo base_url(); ?>/assets/bootstrap/js/bootstrap-datepicker.id.min.js"></script>
<script src="<?php echo base_url(); ?>/assets/js/validasi.js"></script>
<script src="<?php echo base_url(); ?>/assets/js/jquery.validate.min.js"></script>
<script src="<?php echo base_url() . $this->theme_folder . '/' . $this->theme; ?>/assets/js/script.js"></script>
</body>

</html>