<?php if (!defined('BASEPATH')) exit('No direct script access allowed'); ?>
<div id="carouselExampleIndicators" class="carousel slide" data-ride="carousel">
    <ol class="carousel-indicators">
        <!-- <li data-target="#carouselExampleIndicators" data-slide-to="0" class="active"></li>
        <li data-target="#carouselExampleIndicators" data-slide-to="1"></li>
        <li data-target="#carouselExampleIndicators" data-slide-to="2"></li> -->
    </ol>
    <div class="carousel-inner">
        <div class="carousel-item active">
            <!-- menu utama  -->
            <div class="container">
                <div class="index-menu">
                    <div class="row">
                        <div class="col-md-2 col-xs-4 text-center badget rounded">
                            <a class="text-primary" href="<?php echo site_url('berita'); ?>">
                                <div class="card-bg">
                                    <div class="card-body">
                                        <img class="text-center img-thumbnail" src="<?= base_url() ?>/themes/portal/assets/images/badget/berita.png" alt="Berita Desa" width="100">
                                        <div class="index-card-title text-white"><b>Berita</b></div>
                                    </div>
                                </div>
                            </a>
                        </div>

                        <div class="col-md-2 col-xs-4 text-center badget">
                            <a class="text-primary" href="<?php echo site_url('page'); ?>">
                                <div class="card-bg">
                                    <div class="card-body">
                                        <img class="text-center img-thumbnail" src="<?= base_url() ?>/themes/portal/assets/images/badget/profil_desa.png" alt="Profil Desa" width="100">
                                        <div class="index-card-title"><b>Profil <?php echo ucwords($this->setting->sebutan_desa); ?></b></div>
                                    </div>
                                </div>
                            </a>
                        </div>

                        <div class="col-md-2 col-xs-4 text-center badget">
                            <a class="text-primary" href="<?php echo site_url('pemerintah'); ?>">
                                <div class="card-bg">
                                    <div class="card-body">
                                        <img class="text-center img-thumbnail" src="<?= base_url() ?>/themes/portal/assets/images/badget/pemerintah.png" alt="Pemerintah Desa" width="100">
                                        <div class="index-card-title"><b>Pemerintah</b></div>
                                    </div>
                                </div>
                            </a>
                        </div>

                        <div class="col-md-2 col-xs-4 text-center badget">
                            <a class="text-primary" href="<?php echo site_url('inventaris'); ?>">
                                <div class="card-bg">
                                    <div class="card-body">
                                        <img class="text-center img-thumbnail" src="<?= base_url() ?>/themes/portal/assets/images/badget/asset.png" alt="Aset Desa" width="100">
                                        <div class="index-card-title"><b>Aset <?php echo ucwords($this->setting->sebutan_desa); ?></b></div>
                                    </div>
                                </div>
                            </a>
                        </div>

                        <div class="col-md-2 col-xs-4 text-center badget">
                            <a class="text-primary" href="<?php echo site_url('downloads'); ?>">
                                <div class="card-bg">
                                    <div class="card-body">
                                        <img class="text-center img-thumbnail" src="<?= base_url() ?>/themes/portal/assets/images/badget/perdes.png" alt="Peraturan Desa" width="100">
                                        <div class="index-card-title"><b>Regulasi</b></div>
                                    </div>
                                </div>
                            </a>
                        </div>

                        <div class="col-md-2 col-xs-4 text-center badget">
                            <a class="text-primary" href="<?php echo site_url('data-apbdes'); ?>">
                                <div class="card-bg">
                                    <div class="card-body">
                                        <img class="text-center img-thumbnail" src="<?= base_url() ?>/themes/portal/assets/images/badget/apbdes.png" alt="Dana Desa" width="100">
                                        <div class="index-card-title"><b>Anggaran</b></div>
                                    </div>
                                </div>
                            </a>
                        </div>

                        <div class="col-md-2 col-xs-4 text-center badget">
                            <a class="text-primary" href="<?php echo site_url('statistik/list'); ?>">
                                <div class="card-bg">
                                    <div class="card-body">
                                        <img class="text-center img-thumbnail" src="<?= base_url() ?>/themes/portal/assets/images/badget/statistik.png" alt="Statistik Desa" width="100">
                                        <div class="index-card-title"><b>Statistik</b></div>
                                    </div>
                                </div>
                            </a>
                        </div>

                        <div class="col-md-2 col-xs-4 text-center badget">
                            <a class="text-primary" href="<?php echo site_url('agenda'); ?>">
                                <div class="card-bg">
                                    <div class="card-body">
                                        <img class="text-center img-thumbnail" src="<?= base_url() ?>/themes/portal/assets/images/badget/calendar.png" alt="Agenda Desa" width="100">
                                        <div class="index-card-title"><b>Agenda</b></div>
                                    </div>
                                </div>
                            </a>
                        </div>

                        <div class="col-md-2 col-xs-4 text-center badget">
                            <a class="text-primary" href="<?php echo site_url('maps'); ?>">
                                <div class="card-bg">
                                    <div class="card-body">
                                        <img class="text-center img-thumbnail" src="<?= base_url() ?>/themes/portal/assets/images/badget/peta.png" alt="Peta Desa" width="100">
                                        <div class="index-card-title"><b>Peta <?php echo ucwords($this->setting->sebutan_desa); ?></b></div>
                                    </div>
                                </div>
                            </a>
                        </div>

                        <div class="col-md-2 col-xs-4 text-center badget">
                            <a class="text-primary" href="<?php echo site_url('albums'); ?>">
                                <div class="card-bg">
                                    <div class="card-body">
                                        <img class="text-center img-thumbnail" src="<?= base_url() ?>/themes/portal/assets/images/badget/galeri.png" alt="Album Foto" width="100">
                                        <div class="index-card-title"><b>Galeri Foto</b></div>
                                    </div>
                                </div>
                            </a>
                        </div>

                        <div class="col-md-2 col-xs-4 text-center badget">
                            <a class="text-primary" href="<?php echo site_url('layanan_mandiri'); ?>">
                                <div class="card-bg">
                                    <div class="card-body">
                                        <img class="text-center img-thumbnail" src="<?= base_url() ?>/themes/portal/assets/images/badget/mandiri.png" alt="Layanan Mandiri" width="100">
                                        <div class="index-card-title"><b>Layanan</b></div>
                                    </div>
                                </div>
                            </a>
                        </div>


                        <div class="col-md-2 col-xs-4 text-center badget">
                            <a class="text-primary" href="<?php echo site_url('layanan_mandiri'); ?>">
                                <div class="card-bg">
                                    <div class="card-body">
                                        <img class="text-center img-thumbnail" src="<?= base_url() ?>/themes/portal/assets/images/badget/market.png" alt="Produk Desa" width="100">
                                        <div class="index-card-title"><b>Produk Desa</b></div>
                                    </div>
                                </div>
                            </a>
                        </div>
                    </div>
                </div>
            </div>
            <!-- end -->
        </div>
        <div class="carousel-item">

            <!-- menu part 2 -->
            <div class="container">
                <div class="index-menu">
                    <div class="row">



                        <div class="col-md-2 col-xs-4 text-center badget">
                            <a class="text-primary" href="<?php echo site_url('sms'); ?>" target="_blank">
                                <div class="card-bg">
                                    <div class="card-body">
                                        <img class="text-center img-thumbnail" src="<?= base_url() ?>/themes/portal/assets/images/badget/mail.png" alt="sms" width="100">
                                        <div class="index-card-title"><b>Sms</b></div>
                                    </div>
                                </div>
                            </a>
                        </div>




                        <div class="col-md-2 col-xs-4 text-center badget">
                            <a class="text-primary" href="<?php echo site_url('keluarga'); ?>" target="_blank">
                                <div class="card-bg">
                                    <div class="card-body">
                                        <img class="text-center img-thumbnail" src="<?= base_url() ?>/themes/portal/assets/images/badget/family.png" alt="sms" width="100">
                                        <div class="index-card-title"><b>Family</b></div>
                                    </div>
                                </div>
                            </a>
                        </div>

                        <div class="col-md-2 col-xs-4 text-center badget rounded">
                            <a class="text-primary" href="<?php echo site_url('setting'); ?>" target="_blank">
                                <div class="card-bg">
                                    <div class="card-body">
                                        <img class="text-center img-thumbnail" src="<?= base_url() ?>/themes/portal/assets/images/badget/settings.png" alt="Pengaturan" width="100">
                                        <div class="index-card-title text-white"><b>Pengaturan</b></div>
                                    </div>
                                </div>
                            </a>
                        </div>

                        <div class="col-md-2 col-xs-4 text-center badget">
                            <a class="text-primary" href="<?php echo site_url('siteman'); ?>" target="_blank">
                                <div class="card-bg">
                                    <div class="card-body">
                                        <img class="text-center img-thumbnail" src="<?= base_url() ?>/themes/portal/assets/images/badget/admin.png" alt="Administrator" width="100">
                                        <div class="index-card-title"><b>Administrator</b></div>
                                    </div>
                                </div>
                            </a>
                        </div>

                        <div class="col-md-2 col-xs-4 text-center badget">
                            <a class="text-primary" href="<?php echo site_url('surat_master'); ?>" target="_blank">
                                <div class="card-bg">
                                    <div class="card-body">
                                        <img class="text-center img-thumbnail" src="<?= base_url() ?>/themes/portal/assets/images/badget/email.png" alt="surat" width="100">
                                        <div class="index-card-title"><b>Surat</b></div>
                                    </div>
                                </div>
                            </a>
                        </div>



                    </div>
                </div>
            </div>
            <!-- end -->


        </div>

    </div>
    <a class="carousel-control-prev" href="#carouselExampleIndicators" role="button" data-slide="prev">
        <span class="carousel-control-prev-icon" aria-hidden="true"></span>
        <span class="sr-only">Previous</span>
    </a>
    <a class="carousel-control-next" href="#carouselExampleIndicators" role="button" data-slide="next">
        <span class="carousel-control-next-icon" aria-hidden="true"></span>
        <span class="sr-only">Next</span>
    </a>
</div>